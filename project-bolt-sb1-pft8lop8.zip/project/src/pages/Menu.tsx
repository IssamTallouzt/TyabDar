import React, { useState } from 'react';

const menuItems = [
  { name: 'Tajine poulet', category: 'Tajines', price: '15.99', description: 'Chicken with preserved lemons and olives' },
  { name: 'Tajine de légumes', category: 'Tajines', price: '13.99', description: 'Mixed vegetables with Moroccan spices' },
  { name: 'Tajine de boeuf', category: 'Tajines', price: '17.99', description: 'Tender beef with prunes and almonds' },
  { name: 'Salade marocain', category: 'Entrées', price: '6.99', description: 'Fresh mixed vegetables with citrus dressing' },
  { name: 'Harira', category: 'Soupes', price: '7.99', description: 'Traditional Moroccan soup with lentils and chickpeas' },
  { name: 'Bisara', category: 'Soupes', price: '6.99', description: 'Dried fava bean soup with olive oil and cumin' },
  { name: 'Couscous aux légumes', category: 'Couscous', price: '14.99', description: 'Steamed couscous with seven vegetables' },
  { name: 'Couscous tfaya', category: 'Couscous', price: '16.99', description: 'Couscous with caramelized onions and raisins' }
];

const categories = [...new Set(menuItems.map(item => item.category))];

export default function Menu() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredItems = selectedCategory === 'all' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory);

  const handleWhatsAppOrder = () => {
    const orderText = filteredItems
      .map(item => `${item.name} - $${item.price}`)
      .join('\n');
    
    const message = encodeURIComponent(`Hello! I would like to order:\n${orderText}`);
    window.open(`https://wa.me/212783871142?text=${message}`, '_blank');
  };

  return (
    <div className="container mx-auto py-16 px-4 mb-20">
      <h1 className="font-cinzel text-4xl md:text-5xl text-center mb-12">Our Menu</h1>
      
      <div className="flex flex-wrap justify-center gap-4 mb-8">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-6 py-2 rounded-full transition-colors ${
            selectedCategory === 'all' ? 'bg-[#E8C5A7] text-[#2C1810]' : 'bg-[#2C1810]'
          }`}
        >
          All
        </button>
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-6 py-2 rounded-full transition-colors ${
              selectedCategory === category ? 'bg-[#E8C5A7] text-[#2C1810]' : 'bg-[#2C1810]'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {filteredItems.map((item, index) => (
          <div key={index} className="bg-[#2C1810] rounded-lg p-6 hover:bg-[#3D251C] transition-colors">
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-cinzel text-xl">{item.name}</h3>
              <span className="font-poppins text-[#E8C5A7]">${item.price}</span>
            </div>
            <p className="font-poppins text-sm text-[#E8C5A7] opacity-75 mb-4">{item.description}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center">
        <button
          onClick={handleWhatsAppOrder}
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700 transition-colors"
        >
          Order via WhatsApp
        </button>
      </div>
    </div>
  );
}